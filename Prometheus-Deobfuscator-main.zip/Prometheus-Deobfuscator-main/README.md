# Prometheus Deobfuscator

prometheus deobfuscator — supports wearedevs fork + latest version · MIT

by **LeakD** · [https://leakd.vercel.app](https://leakd.vercel.app)

---

```bash
git clone https://github.com/prostone4/Prometheus-Deobfuscator
```

```bash
node bin/pdeobf.js script.lua
node bin/pdeobf.js script.lua -o out.lua
```

> requires node 16+

