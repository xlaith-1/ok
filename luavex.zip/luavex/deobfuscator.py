#!/usr/bin/env python3
"""
luavex_deobfuscator - full static + hybrid-dynamic deobfuscator for scripts
protected by Luavex 2.2 (https://luavex.pntr.dev).

Pure Python. No third-party pip dependencies (the only external binary used
is the bundled/auto-fetched `lune` Luau runtime for the dynamic stage).

Produces exactly ONE output file per input: `<name>.deobfuscated.lua`,
containing the best available reconstruction of the script's REAL original
source -- not a relabeled copy of Luavex's own wrapper/VM code.

How real source is recovered
-----------------------------
Luavex compiles the protected program into a custom register-based bytecode
VM baked into the file. That bytecode is not readable Lua and can't be
turned back into source by text-level decoding alone. Instead this tool
actually *runs* the original, untouched script inside the Lune Luau runtime
with an instrumented global environment ("envlog"):

  * every global the script looks up -- whether by a literal name in the
    source, or (as Luavex's own bootstrap does) a name only decoded at
    runtime -- transparently resolves to a logging object if it isn't a
    real Luau stdlib member, letting the script run deep into Roblox/
    exploit-only APIs that don't exist in this sandbox without crashing;
  * every call made with real, resolved arguments is recorded in order;
  * the script's own outbound HTTP call(s) are, by default, actually sent
    for real (see --no-network to disable this) -- nothing is spoofed or
    fabricated, the exact request the script built is forwarded and its
    real response handed back. For Luavex-protected scripts this is what
    lets the script's own license/telemetry round-trip succeed so it falls
    through into its real, protected program logic instead of panicking.

The resulting execution trace (globals touched, real call arguments,
property writes, print/warn output) is then replayed back into literal
Lua statements -- e.g. a trace entry for a call to `print` with the single
argument "Hello Luavex" becomes the output line `print("Hello Luavex")`,
exactly the statement the original author wrote. Luavex's own injected
license/telemetry call is recognized and dropped from the output since it
is protector machinery, not anything the original author wrote.

If the dynamic stage can't run at all (no lune runtime available, or the
script produces no usable trace), the tool falls back to its static
pipeline: decoding Luavex's panic-string bootstrap and inlining its XOR
string tables, then beautifying the result. This fallback output is
Luavex's own wrapper/VM-dispatch code made readable -- it is clearly
inferior to a real dynamic recovery and is only used when dynamic recovery
is unavailable.

Usage
-----
    python3 deobfuscator.py input.lua
    python3 deobfuscator.py input.lua -o out/ --fetch-lune

See command.txt for ready-to-paste commands.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from luavex_tools import decoder, beautifier, sandbox, reconstruct  # noqa: E402


def _read_text(path: Path) -> str:
    data = path.read_bytes()
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _static_fallback(src: str) -> str:
    out, _report = decoder.run_static_pipeline(src)
    return beautifier.beautify(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="deobfuscator.py",
        description="Full static + hybrid-dynamic deobfuscator for Luavex 2.2 protected Lua/Luau scripts. "
                     "Outputs exactly one <name>.deobfuscated.lua file containing the recovered real source.",
    )
    ap.add_argument("input", help="path to the Luavex-protected .lua/.luau/.txt file")
    ap.add_argument("-o", "--outdir", default=None, help="output directory (default: next to input)")
    ap.add_argument("--static-only", action="store_true",
                     help="skip dynamic recovery entirely, just clean up Luavex's own wrapper/VM code")
    ap.add_argument("--lune", default=None, help="explicit path to a lune executable")
    ap.add_argument("--fetch-lune", action="store_true",
                     help="download a matching lune binary automatically if none is found")
    ap.add_argument("--no-network", action="store_true",
                     help="do not let the sandboxed script's network calls go out for real "
                          "(default: real network calls are allowed, since Luavex-protected scripts "
                          "generally need their own license/telemetry round-trip to succeed before "
                          "their real logic runs). With this flag, network calls are answered locally "
                          "and recovery will usually be limited to whatever runs before that point.")
    ap.add_argument("--timeout", type=int, default=25, help="dynamic sandbox run timeout in seconds (default 25)")
    args = ap.parse_args(argv)

    in_path = Path(args.input)
    if not in_path.is_file():
        print(f"error: no such file: {in_path}", file=sys.stderr)
        return 1

    outdir = Path(args.outdir) if args.outdir else in_path.parent
    outdir.mkdir(parents=True, exist_ok=True)
    stem = in_path.stem
    out_path = outdir / f"{stem}.deobfuscated.lua"

    src = _read_text(in_path)
    print(f"[*] loaded {in_path} ({len(src)} bytes)")

    final_src = None
    method = None

    if not args.static_only:
        print("[*] running hybrid dynamic recovery (Lune 'envlog' sandbox) ...")
        lp = sandbox.find_lune(args.lune)
        if not lp and not args.fetch_lune:
            print("    ! lune runtime not found on PATH / ./tools / ./.")
            print("    ! re-run with --fetch-lune to download it automatically, or pass --lune /path/to/lune")
            print("    ! falling back to static recovery")
        else:
            result = sandbox.run_dynamic_analysis(
                str(in_path),
                lune_path=args.lune,
                fetch_lune=args.fetch_lune,
                allow_network=not args.no_network,
                timeout_seconds=args.timeout,
            )
            if not result.ran:
                print(f"    ! dynamic stage did not run: {result.status} - {result.message}")
                print("    ! falling back to static recovery")
            else:
                statements = reconstruct.reconstruct(result.trace_entries)
                print(f"    - sandbox finished with status: {result.status} ({result.message!r})")
                print(f"    - trace entries captured      : {len(result.trace_entries)}"
                      f"{' (truncated)' if result.truncated else ''}")
                print(f"    - real statements recovered   : {len(statements)}")
                if statements:
                    final_src = "\n".join(statements) + "\n"
                    method = "dynamic"
                else:
                    print("    ! no real program logic was reached (nothing usable to recover)")
                    print("    ! falling back to static recovery")
    else:
        print("[*] --static-only passed, skipping dynamic recovery")

    if final_src is None:
        print("[*] running static decode/beautify pipeline ...")
        final_src = _static_fallback(src)
        method = "static-fallback"

    out_path.write_text(final_src, encoding="utf-8")
    print(f"[+] wrote {out_path}  (recovery method: {method})")
    print("[*] done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
