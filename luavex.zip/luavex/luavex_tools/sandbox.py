"""
Orchestrates the hybrid dynamic ("envlog" + Lune sandbox) analysis stage.

This module is pure Python; it only shells out to a `lune` binary (the
standalone Luau runtime, https://lune-org.github.io/) which it will locate
on PATH, in a local `./tools` folder next to this package, or offer to
download from lune's GitHub releases if the machine has internet access and
the user passes --fetch-lune.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from . import harness_template

LUNE_VERSION = "0.10.5"
GITHUB_RELEASE = f"https://github.com/lune-org/lune/releases/download/v{LUNE_VERSION}/"


@dataclass
class SandboxResult:
    ran: bool
    lune_path: Optional[str] = None
    status: str = "not-run"
    message: str = ""
    trace_entries: list = field(default_factory=list)
    truncated: bool = False
    error: Optional[str] = None
    raw_trace_path: Optional[str] = None


def _asset_name_for_platform() -> Optional[str]:
    system = platform.system().lower()
    machine = platform.machine().lower()
    arch = "x86_64" if machine in ("x86_64", "amd64") else (
        "aarch64" if machine in ("arm64", "aarch64") else None)
    if arch is None:
        return None
    if system == "linux":
        return f"lune-{LUNE_VERSION}-linux-{arch}.zip"
    if system == "darwin":
        return f"lune-{LUNE_VERSION}-macos-{arch}.zip"
    if system == "windows":
        if arch != "x86_64":
            return None
        return f"lune-{LUNE_VERSION}-windows-x86_64.zip"
    return None


def find_lune(explicit_path: Optional[str] = None) -> Optional[str]:
    if explicit_path:
        p = Path(explicit_path)
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    exe = "lune.exe" if platform.system().lower() == "windows" else "lune"
    on_path = shutil.which("lune")
    if on_path:
        return on_path
    here = Path(__file__).resolve().parent.parent
    for candidate in (here / "tools" / exe, here / exe):
        if candidate.is_file():
            return str(candidate)
    return None


def download_lune(dest_dir: str) -> Optional[str]:
    """Best-effort download of a matching lune binary into dest_dir.
    Returns the path to the extracted executable, or None on any failure
    (no internet, unsupported platform, etc). Never raises."""
    asset = _asset_name_for_platform()
    if not asset:
        return None
    url = GITHUB_RELEASE + asset
    os.makedirs(dest_dir, exist_ok=True)
    zip_path = os.path.join(dest_dir, asset)
    try:
        urllib.request.urlretrieve(url, zip_path)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(dest_dir)
    except Exception:
        return None
    finally:
        try:
            os.remove(zip_path)
        except OSError:
            pass
    exe = "lune.exe" if platform.system().lower() == "windows" else "lune"
    exe_path = os.path.join(dest_dir, exe)
    if os.path.isfile(exe_path):
        st = os.stat(exe_path)
        os.chmod(exe_path, st.st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
        return exe_path
    return None


def run_dynamic_analysis(original_source_path: str, *, lune_path: Optional[str] = None,
                          fetch_lune: bool = False, allow_network: bool = False,
                          timeout_seconds: int = 20, work_dir: Optional[str] = None) -> SandboxResult:
    """Run the original (unmodified) obfuscated script inside the Lune
    "envlog" sandbox and collect an execution trace. Never raises; failures
    are reported through SandboxResult.error."""
    resolved = find_lune(lune_path)
    if not resolved and fetch_lune:
        tmp_tools = work_dir or tempfile.mkdtemp(prefix="luavex_lune_")
        resolved = download_lune(tmp_tools)
    if not resolved:
        return SandboxResult(
            ran=False, status="no-lune",
            message=(
                "lune (the standalone Luau runtime) was not found and was not downloaded. "
                "Install it from https://github.com/lune-org/lune/releases, put it on PATH "
                "(or pass --lune /path/to/lune), or re-run with --fetch-lune to auto-download it."
            ),
        )

    work_dir = work_dir or tempfile.mkdtemp(prefix="luavex_sandbox_")
    os.makedirs(work_dir, exist_ok=True)

    harness_path = os.path.join(work_dir, "harness.luau")
    config_path = os.path.join(work_dir, "config.json")
    trace_path = os.path.join(work_dir, "trace.json")

    with open(harness_path, "w", encoding="utf-8") as f:
        f.write(harness_template.HARNESS_SOURCE)

    config_json = harness_template.build_config(
        target_path=str(Path(original_source_path).resolve()),
        trace_path=trace_path,
        allow_network=allow_network,
        timeout_seconds=timeout_seconds,
    )
    with open(config_path, "w", encoding="utf-8") as f:
        f.write(config_json)

    try:
        proc = subprocess.run(
            [resolved, "run", harness_path, config_path],
            cwd=work_dir,
            capture_output=True,
            text=True,
            timeout=timeout_seconds + 15,
        )
    except subprocess.TimeoutExpired:
        return SandboxResult(
            ran=False, lune_path=resolved, status="process-timeout",
            message="The lune subprocess itself was killed after exceeding the outer timeout.",
        )
    except Exception as exc:  # pragma: no cover - defensive
        return SandboxResult(ran=False, lune_path=resolved, status="subprocess-error", error=str(exc))

    stdout_tail = (proc.stdout or "")[-4000:]
    stderr_tail = (proc.stderr or "")[-4000:]

    if not os.path.isfile(trace_path):
        return SandboxResult(
            ran=True, lune_path=resolved, status="no-trace",
            message="The sandbox process produced no trace file.",
            error=(stderr_tail or stdout_tail or None),
        )

    try:
        with open(trace_path, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception as exc:
        return SandboxResult(ran=True, lune_path=resolved, status="trace-parse-error", error=str(exc))

    trace = payload.get("trace") or {}
    if isinstance(trace, dict):
        try:
            entries = [trace[k] for k in sorted(trace, key=lambda x: int(x))]
        except Exception:
            entries = list(trace.values())
    else:
        entries = list(trace)

    return SandboxResult(
        ran=True,
        lune_path=resolved,
        status=payload.get("status", "unknown"),
        message=str(payload.get("message", "")),
        trace_entries=entries,
        truncated=bool(payload.get("truncated")),
        raw_trace_path=trace_path,
    )
