"""
Turns a hybrid-dynamic execution trace (see sandbox.py / harness_template.py)
into clean, directly-readable Lua statements -- the actual recovered
program, not a log of what a mock object saw.

The trace already tells us, in order, every real action the protected
program took (globals touched, calls made with real arguments, property
writes, print/warn output). This module replays that into Lua source text:
the same `path`/`args` shape that produced `print("Hello Luavex")` in the
trace becomes the literal line `print("Hello Luavex")` here -- nothing
about mocks, blocking, or the sandbox leaks into the output.

Luavex's own injected license/telemetry "gate" call (always a `request`-like
call whose URL/body mentions luavex) is filtered out: it is machinery the
protector added, not anything the original author wrote.
"""
from __future__ import annotations

import re
from typing import Any, Optional

_MOCK_RE = re.compile(r"^<mock:(.+)>$")
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _lua_quote(s: str) -> str:
    out = ['"']
    for ch in s:
        if ch == "\\":
            out.append("\\\\")
        elif ch == '"':
            out.append('\\"')
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif 32 <= ord(ch) < 127:
            out.append(ch)
        else:
            out.append("\\%d" % ord(ch))
    out.append('"')
    return "".join(out)


def _fmt_number(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return repr(v)


def _fmt_literal(value: Any, expr_for: dict) -> str:
    if value is None:
        return "nil"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return _fmt_number(value)
    if isinstance(value, str):
        m = _MOCK_RE.match(value)
        if m:
            return expr_for.get(m.group(1), m.group(1))
        return _lua_quote(value)
    if isinstance(value, list):
        return "{" + ", ".join(_fmt_literal(v, expr_for) for v in value) + "}"
    if isinstance(value, dict):
        parts = []
        for k, v in value.items():
            if isinstance(k, str) and _IDENT_RE.match(k):
                parts.append(f"{k} = {_fmt_literal(v, expr_for)}")
            else:
                parts.append(f"[{_lua_quote(str(k))}] = {_fmt_literal(v, expr_for)}")
        return "{" + ", ".join(parts) + "}"
    return _lua_quote(str(value))


def _contains_luavex_marker(value: Any) -> bool:
    if isinstance(value, str):
        return "luavex" in value.lower()
    if isinstance(value, list):
        return any(_contains_luavex_marker(v) for v in value)
    if isinstance(value, dict):
        return any(_contains_luavex_marker(v) for v in value.values())
    return False


def _split_receiver(path: str) -> tuple[Optional[str], str]:
    if "." in path:
        receiver, method = path.rsplit(".", 1)
        return receiver, method
    return None, path


def _resolve_expr(path: Optional[str], expr_for: dict) -> Optional[str]:
    """Resolves a mock path to Lua source text, substituting the nearest
    known call-result variable as a prefix when the exact path itself was
    never a call result (e.g. a plain property read like `.Name` chained
    off a call result that *was* assigned a variable)."""
    if path is None:
        return None
    if path in expr_for:
        return expr_for[path]
    best_key = None
    for known_path in expr_for:
        if known_path.endswith(")") and (path == known_path or path.startswith(known_path + ".")):
            if best_key is None or len(known_path) > len(best_key):
                best_key = known_path
    if best_key is not None:
        return expr_for[best_key] + path[len(best_key):]
    return path


def reconstruct(trace_entries: list) -> list[str]:
    """Returns a list of clean Lua statement strings, in execution order."""
    entries = [e for e in trace_entries if isinstance(e, dict)]

    all_paths = [e.get("path") for e in entries if e.get("path")]
    call_events = [e for e in entries if e.get("kind") == "call"]

    used_as_receiver = set()
    for e in call_events:
        result_path = e["path"] + "()"
        prefix = result_path + "."
        if any(p != result_path and p.startswith(prefix) for p in all_paths):
            used_as_receiver.add(result_path)

    statements: list[str] = []
    expr_for: dict[str, str] = {}
    var_counter = 1

    for e in entries:
        kind = e.get("kind")

        if kind in ("index", "global_access", "net_response", "net_error"):
            continue

        if kind == "print" or kind == "warn":
            args = e.get("args", [])
            statements.append(f"{kind}({', '.join(_fmt_literal(a, expr_for) for a in args)})")
            continue

        if kind == "newindex":
            path = e.get("path", "")
            value = e.get("value")
            receiver_path, key = _split_receiver(path)
            receiver_expr = _resolve_expr(receiver_path, expr_for)
            target = f"{receiver_expr}.{key}" if receiver_expr else key
            statements.append(f"{target} = {_fmt_literal(value, expr_for)}")
            continue

        if kind == "call":
            path = e.get("path", "")
            args = e.get("args", [])

            # Drop Luavex's own injected license/telemetry "gate" call --
            # it's protector machinery, not anything the original author
            # wrote. Recognizable by a luavex-branded URL/header in its args.
            if _contains_luavex_marker(args):
                continue

            receiver_path, method = _split_receiver(path)
            receiver_expr = _resolve_expr(receiver_path, expr_for)

            call_args = args
            is_method = False
            if args and isinstance(args[0], str) and receiver_path:
                m = _MOCK_RE.match(args[0])
                if m and m.group(1) == receiver_path:
                    is_method = True
                    call_args = args[1:]

            formatted_args = ", ".join(_fmt_literal(a, expr_for) for a in call_args)
            if is_method:
                call_expr = f"{receiver_expr}:{method}({formatted_args})"
            elif receiver_expr:
                call_expr = f"{receiver_expr}.{method}({formatted_args})"
            else:
                call_expr = f"{method}({formatted_args})"

            result_path = path + "()"
            if result_path in used_as_receiver:
                varname = f"obj{var_counter}"
                var_counter += 1
                statements.append(f"local {varname} = {call_expr}")
                expr_for[result_path] = varname
            else:
                statements.append(call_expr)
            continue

        # Unknown trace kind -- ignore rather than leak internal bookkeeping
        # into the recovered source.

    return statements
