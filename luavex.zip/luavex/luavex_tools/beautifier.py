"""
A conservative, lexer-based Lua/Luau pretty-printer.

Luavex (like most minifying obfuscators) emits the entire script as one
giant line with no whitespace beyond what Lua's grammar strictly requires.
This module re-inserts newlines and indentation using simple, well known
heuristics (track a block-depth counter, break after `;`/block-opening
keywords, break before block-closing keywords) so humans can actually read
the result. It never changes token order or token text, so it cannot change
program behaviour -- worst case the formatting looks a little odd for some
exotic construct.
"""
from __future__ import annotations

from . import lua_lexer

INDENT = "    "

_OPENERS_SIMPLE = {"do", "then", "repeat", "function"}
_CLOSERS = {"end", "until"}


def beautify(src: str) -> str:
    # Lua/Luau grammar is whitespace-insensitive (no automatic-semicolon
    # ambiguity like JS): inserting newlines between existing tokens can
    # never change how the program parses, since we never add/remove/
    # reorder tokens, only whitespace between them. So breaking is always
    # safe, regardless of paren/brace nesting.
    tokens = lua_lexer.tokenize(src)
    out_lines = []
    cur = []
    depth = 0

    def flush_line():
        nonlocal cur
        text = "".join(cur).strip()
        if text:
            out_lines.append(INDENT * max(depth, 0) + text)
        cur = []

    i = 0
    n = len(tokens)
    awaiting_function_params = False
    func_paren_depth = 0

    while i < n:
        tok = tokens[i]
        if tok.kind == "eof":
            break

        needs_space = False
        if cur:
            last = cur[-1]
            if last and tok.text:
                a, b = last[-1], tok.text[0]
                if (a.isalnum() or a == "_") and (b.isalnum() or b == "_"):
                    needs_space = True
                elif a in "+-*/%^#<>=~." and b in "+-*/%^#<>=~.":
                    needs_space = True

        if tok.kind == "keyword" and tok.text in ("end", "until", "else", "elseif"):
            flush_line()
            depth = max(0, depth - 1)

        # These keywords only ever start a new statement in Lua grammar, so
        # breaking the line right before them is always safe and makes the
        # very common `local a local b local c` (no separating ';') pattern
        # readable.
        if tok.kind == "keyword" and tok.text in ("local", "return", "break", "goto", "if", "for", "while") and cur:
            flush_line()

        if needs_space:
            cur.append(" ")
        cur.append(tok.text)

        # `function NAME? ( params )` doesn't use 'do', so track its param
        # list manually to still get a matching indent/dedent pair.
        if tok.kind == "keyword" and tok.text == "function":
            awaiting_function_params = True
            func_paren_depth = 0
        elif awaiting_function_params and tok.kind == "op" and tok.text == "(":
            func_paren_depth += 1
        elif awaiting_function_params and tok.kind == "op" and tok.text == ")":
            func_paren_depth -= 1
            if func_paren_depth <= 0:
                awaiting_function_params = False
                flush_line()
                depth += 1
                i += 1
                continue

        if tok.kind == "op" and tok.text == ";":
            flush_line()
        elif tok.kind == "keyword" and tok.text in ("do", "then", "repeat", "else"):
            flush_line()
            depth += 1
        elif tok.kind in ("comment", "longcomment"):
            flush_line()

        i += 1

    flush_line()
    return "\n".join(out_lines) + "\n"
