"""
A small, dependency-free Lua / Luau lexer.

It is not a full parser -- it only tokenizes the source into a flat list of
tokens (strings, long-strings, comments, numbers, names, keywords, and
punctuation/operators). This is enough to safely:

  * find matching parentheses / braces without being confused by text that
    looks like Lua syntax inside string literals,
  * split the source into top level statements for the beautifier,
  * locate identifiers used as "free" globals for the sandbox scanner.

Supported Luau extensions: `//` floor division, `+=`, `-=`, `*=`, `/=`,
`//=`, `%=`, `^=`, `..=`, `continue` as a name (not a Lua keyword, Luau
doesn't reserve it either, it's handled specially by the parser -- we treat
it as a NAME token here which is fine for our purposes).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

KEYWORDS = {
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return",
    "then", "true", "until", "while",
}

_LONG_BRACKET_OPEN = re.compile(r"\[(=*)\[")

_NAME_START = re.compile(r"[A-Za-z_]")
_NAME_CONT = re.compile(r"[A-Za-z0-9_]")
_NUMBER = re.compile(
    r"0[xX][0-9a-fA-F]+(?:\.[0-9a-fA-F]*)?(?:[pP][+-]?\d+)?"
    r"|\d+\.?\d*(?:[eE][+-]?\d+)?"
    r"|\.\d+(?:[eE][+-]?\d+)?"
)

MULTI_OPS = [
    "...", "..=", "//=", "..", "==", "~=", "<=", ">=", "::", "//",
    "+=", "-=", "*=", "/=", "%=", "^=",
]


@dataclass
class Token:
    kind: str   # 'name' | 'keyword' | 'string' | 'longstring' | 'comment' |
                # 'longcomment' | 'number' | 'op' | 'eof'
    text: str   # raw source text, exactly as it appeared
    start: int
    end: int
    line: int


def tokenize(src: str):
    """Yield Token objects for the whole source. Never raises on malformed
    input; best-effort recovery (unterminated strings consume to EOF)."""
    i = 0
    n = len(src)
    line = 1
    tokens = []

    def count_lines(a, b):
        return src.count("\n", a, b)

    while i < n:
        c = src[i]

        if c in " \t\r\n":
            line += 1 if c == "\n" else 0
            i += 1
            continue

        # comments
        if src.startswith("--", i):
            m = _LONG_BRACKET_OPEN.match(src, i + 2)
            if m:
                eqs = m.group(1)
                close = "]" + eqs + "]"
                j = src.find(close, m.end())
                end = (j + len(close)) if j != -1 else n
                tokens.append(Token("longcomment", src[i:end], i, end, line))
                line += count_lines(i, end)
                i = end
                continue
            else:
                j = src.find("\n", i)
                end = j if j != -1 else n
                tokens.append(Token("comment", src[i:end], i, end, line))
                i = end
                continue

        # long strings
        if c == "[":
            m = _LONG_BRACKET_OPEN.match(src, i)
            if m:
                eqs = m.group(1)
                close = "]" + eqs + "]"
                j = src.find(close, m.end())
                end = (j + len(close)) if j != -1 else n
                tokens.append(Token("longstring", src[i:end], i, end, line))
                line += count_lines(i, end)
                i = end
                continue

        # strings
        if c == '"' or c == "'":
            quote = c
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == quote or src[j] == "\n":
                    break
                j += 1
            end = j + 1 if j < n and src[j] == quote else min(j, n)
            tokens.append(Token("string", src[i:end], i, end, line))
            i = end
            continue

        # numbers
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            m = _NUMBER.match(src, i)
            end = m.end()
            tokens.append(Token("number", src[i:end], i, end, line))
            i = end
            continue

        # names / keywords
        if _NAME_START.match(c):
            j = i + 1
            while j < n and _NAME_CONT.match(src[j]):
                j += 1
            text = src[i:j]
            kind = "keyword" if text in KEYWORDS else "name"
            tokens.append(Token(kind, text, i, j, line))
            i = j
            continue

        # multi-char operators
        matched = None
        for op in MULTI_OPS:
            if src.startswith(op, i):
                matched = op
                break
        if matched:
            tokens.append(Token("op", matched, i, i + len(matched), line))
            i += len(matched)
            continue

        # single-char operator / punctuation
        tokens.append(Token("op", c, i, i + 1, line))
        i += 1

    tokens.append(Token("eof", "", n, n, line))
    return tokens


def find_matching_paren(src: str, open_pos: int) -> int:
    """Given the index of an opening '(' '[' or '{' in src, return the index
    of the matching closer, lexer-aware (ignores brackets inside strings and
    comments). Returns -1 if not found."""
    opener = src[open_pos]
    closer = {"(": ")", "[": "]", "{": "}"}[opener]
    depth = 0
    toks = tokenize(src[open_pos:])
    for t in toks:
        if t.kind == "op":
            if t.text == opener:
                depth += 1
            elif t.text == closer:
                depth -= 1
                if depth == 0:
                    return open_pos + t.end
    return -1
