"""
Static deobfuscation passes for Luavex-protected Lua/Luau scripts.

These passes are purely textual / semantics-preserving. They never execute
any Lua code. Everything here was reverse engineered by reading the
(un-virtualized) bootstrap code that Luavex 2.2 ships in clear text inside
every protected script -- the bootstrap is responsible for recovering a
handful of hidden identifiers/strings before the real virtual machine
(registers/constants/instructions) takes over.

Layers implemented
-------------------
1. `fold_constants`      - collapses disguised numeric literals such as
                            `(390-164)` into plain integers. Always safe:
                            pure integer arithmetic on literal operands.
2. `decode_qd_tables`    - inlines Luavex's "table of bytes XOR single key"
                            string obfuscation (`local function _qd(v) ...
                            bit32.bxor(v[i], KEY) ... end`) wherever the
                            resulting helper is later called with a literal
                            array, e.g. `_qd({7,27,...})` -> `"actual text"`.
3. `annotate_panic_stubs`- finds Luavex's repeated "_a/_z/_s/_p" bootstrap
                            (used to hide the literal string that is handed
                            to `error(...)` when an integrity/env check
                            fails) and decodes it, replacing the whole
                            (self-contained, side-effect-free) prelude with
                            a single readable comment + a literal `_s` table
                            so later references to `_s`/`_e`/`_m` keep
                            working unmodified. This never touches code that
                            follows the prelude (which sometimes smuggles in
                            unrelated, *necessary* side-effecting statements
                            right before the final `error()` call), so it is
                            safe even though it is a more invasive rewrite
                            than the previous two passes.

All passes are generic: they look for the *shape* of the construct (via the
lexer in `lua_lexer.py`), not for file-specific variable names, so they
should keep working across different Luavex 2.2 builds where only the
random local-variable names and per-string keys change.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from . import lua_lexer

BASE92_TABLE = ("!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                "[]^_`abcdefghijklmnopqrstuvwxyz{|}~")
BASE92_INDEX = {c: i for i, c in enumerate(BASE92_TABLE)}


# ---------------------------------------------------------------------------
# Pass 1: constant folding  (390-164) -> 226
# ---------------------------------------------------------------------------

_FOLD_RE = re.compile(r"(?<![\w.])(\d+)\s*([+\-])\s*(\d+)(?![\w.])")


def fold_constants(src: str, max_passes: int = 6) -> str:
    """Repeatedly collapse `N+M` / `N-M` literal-integer arithmetic.

    Runs only on the "code" regions as seen by the lexer -- strings and
    comments are left completely untouched, so this can never corrupt a
    literal that happens to look like `12-3` inside a string.
    """
    for _ in range(max_passes):
        changed = False
        out = []
        pos = 0
        for tok in lua_lexer.tokenize(src):
            if tok.start > pos:
                out.append(_fold_chunk(src[pos:tok.start]))
            if tok.kind in ("string", "longstring", "comment", "longcomment"):
                out.append(tok.text)
            elif tok.kind == "op":
                out.append(tok.text)
            else:
                out.append(tok.text)
            pos = tok.end
        if pos < len(src):
            out.append(_fold_chunk(src[pos:]))
        new_src = "".join(out)
        changed = new_src != src
        src = new_src
        if not changed:
            break
    return src


def _fold_chunk(chunk: str) -> str:
    def repl(m: "re.Match[str]") -> str:
        a, op, b = m.group(1), m.group(2), m.group(3)
        val = int(a) + int(b) if op == "+" else int(a) - int(b)
        return str(val)

    prev = None
    while prev != chunk:
        prev = chunk
        chunk = _FOLD_RE.sub(repl, chunk)
    return chunk


# ---------------------------------------------------------------------------
# Pass 2: inline `_qd({...})`-style single-key XOR string tables
# ---------------------------------------------------------------------------

_QD_DEF_RE = re.compile(
    r"local\s+function\s+(?P<name>\w+)\s*\(\s*(?P<param>\w+)\s*\)\s*"
    r"local\s+(?P<out>\w+)\s*=\s*\{\s*\}\s*"
    r"for\s+(?P<i>\w+)\s*=\s*1\s*,\s*#\s*(?P=param)\s+do\s+"
    r"(?P=out)\[(?P=i)\]\s*=\s*string\.char\(\s*bit32\.bxor\(\s*(?P=param)\[(?P=i)\]\s*,\s*(?P<key>\d+)\s*\)\s*\)\s*"
    r"end\s+return\s+table\.concat\(\s*(?P=out)\s*\)\s*end"
)


def _lua_escape(s: str) -> str:
    out = []
    for ch in s:
        o = ord(ch)
        if ch == "\\":
            out.append("\\\\")
        elif ch == '"':
            out.append('\\"')
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif 32 <= o < 127:
            out.append(ch)
        else:
            out.append("\\%d" % o)
    return '"' + "".join(out) + '"'


@dataclass
class QdDecoderInfo:
    name: str
    key: int
    def_start: int
    def_end: int


def find_qd_decoders(src: str) -> list[QdDecoderInfo]:
    found = []
    for m in _QD_DEF_RE.finditer(src):
        found.append(QdDecoderInfo(m.group("name"), int(m.group("key")), m.start(), m.end()))
    return found


_ARRAY_LITERAL_RE = re.compile(r"\{\s*(?:-?\d+\s*(?:,\s*-?\d+\s*)*)?\}")


def decode_qd_tables(src: str, decoders: Optional[list[QdDecoderInfo]] = None) -> tuple[str, int]:
    """Replace every `NAME({n1,n2,...})` call (NAME being one of the XOR
    helpers found by `find_qd_decoders`) with the decoded string literal.
    The helper definition itself is left in place (some scripts keep calling
    it dynamically / it's harmless), only pure-literal call sites are
    folded. Returns (new_src, number_of_replacements)."""
    if decoders is None:
        decoders = find_qd_decoders(src)
    if not decoders:
        return src, 0

    # Position-aware lookup: a script could (in principle) define several
    # same-named decoders with different keys in different scopes (Luavex's
    # panic-stub bootstrap does exactly this for a different helper). For
    # each call site we pick the *nearest preceding* definition of that
    # name, which matches ordinary lexical shadowing in the common case
    # where each helper is defined immediately before the code that uses it.
    by_name: dict[str, list[QdDecoderInfo]] = {}
    for d in decoders:
        by_name.setdefault(d.name, []).append(d)
    for lst in by_name.values():
        lst.sort(key=lambda d: d.def_start)

    def key_for(name: str, call_pos: int) -> Optional[int]:
        best = None
        for d in by_name.get(name, ()):
            if d.def_end <= call_pos:
                best = d
            else:
                break
        if best is None and by_name.get(name):
            best = by_name[name][0]
        return best.key if best else None

    count = 0
    out = []
    i = 0
    n = len(src)
    name_pattern = re.compile(r"(" + "|".join(re.escape(k) for k in by_name) + r")\s*\(\s*\{")
    while i < n:
        m = name_pattern.search(src, i)
        if not m:
            out.append(src[i:])
            break
        out.append(src[i:m.start()])
        name = m.group(1)
        brace_pos = src.index("{", m.end() - 1)
        close = lua_lexer.find_matching_paren(src, brace_pos)
        if close == -1:
            out.append(src[m.start():m.end()])
            i = m.end()
            continue
        array_text = src[brace_pos:close]
        # call has to end right after the closing '}' then ')'
        after = src[close:].lstrip()
        if not after.startswith(")"):
            out.append(src[m.start():close])
            i = close
            continue
        call_end = close + (len(src[close:]) - len(after)) + 1
        if _ARRAY_LITERAL_RE.fullmatch(array_text.replace("\n", "").replace(" ", "") or "{}") is None:
            # not a pure literal array (contains expressions) -- leave as-is
            out.append(src[m.start():call_end])
            i = call_end
            continue
        nums = [int(x) for x in re.findall(r"-?\d+", array_text)]
        key = key_for(name, m.start())
        if key is None:
            out.append(src[m.start():call_end])
            i = call_end
            continue
        try:
            decoded = "".join(chr((v ^ key) & 0xFF) for v in nums)
        except Exception:
            out.append(src[m.start():call_end])
            i = call_end
            continue
        out.append(_lua_escape(decoded))
        count += 1
        i = call_end
    return "".join(out), count


# ---------------------------------------------------------------------------
# Pass 3: decode + annotate the "_a/_z/_s/_p" panic-string bootstrap
# ---------------------------------------------------------------------------

_STUB_HEAD_RE = re.compile(
    r"local\s+function\s+(?P<z>\w+)\(\)\s*local\s+(?P<v>\w+)\s*=\s*nil\s*;?\s*"
    r"return\s+(?P=v)\(\)\s*end\s*;?"
    r"local\s+(?P<s>\w+)\s*=\s*\{\s*\}\s*;?"
    r"local\s+(?P<p>\w+)\s*=\s*0\s*;?"
    r"local\s+function\s+(?P<a>\w+)\((?P<x>\w+)\s*,\s*(?P<f>\w+)\)"
)


@dataclass
class PanicStub:
    start: int                 # start of "local function _z()"
    end: int                   # end of the 4th `_a(...)` call statement (inclusive of ';')
    rot: int
    key: int
    s_name: str
    z_name: str
    e_value: str
    m_value: str
    full_text: str


def _parse_string_char_args(args_text: str) -> list[int]:
    vals = []
    depth = 0
    cur = ""
    for ch in args_text:
        if ch == "(":
            depth += 1
            cur += ch
        elif ch == ")":
            depth -= 1
            cur += ch
        elif ch == "," and depth == 0:
            vals.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        vals.append(cur)
    out = []
    for v in vals:
        v = v.strip()
        m = re.match(r"^\(?\s*(\d+)\s*([+\-])\s*(\d+)\s*\)?$", v)
        if m:
            a, op, b = m.groups()
            out.append(int(a) + int(b) if op == "+" else int(a) - int(b))
        else:
            out.append(int(v))
    return out


class _StubDecoderSim:
    def __init__(self, rot: int, key: int):
        self.rot = rot
        self.key = key
        self.p = 0
        self.slots: dict[int, str] = {}

    def feed(self, byte_vals: list[int], f: int):
        if f == 3:
            for i in range(0, len(byte_vals), 2):
                u = chr(byte_vals[i])
                v = chr(byte_vals[i + 1])
                ui = BASE92_INDEX.get(u)
                vi = BASE92_INDEX.get(v)
                if ui is None or vi is None:
                    raise ValueError("bad base92 char in stub payload")
                d = ui * 92 + vi
                self.p += 1
                idx = (self.p + self.rot - 1) % 18
                self.slots[idx] = chr((d - self.key) % 256)
        else:
            for i in range(0, len(byte_vals), 3):
                c1, c2, c3 = byte_vals[i], byte_vals[i + 1], byte_vals[i + 2]
                d = (c1 - 224) * 4096 + (c2 - 128) * 64 + c3 - 128
                if f == 0:
                    b = 19968
                elif f == 1:
                    b = 10240
                else:
                    if d >= 19968:
                        b = 19968
                    elif d >= 9728:
                        b = 9728
                    elif d >= 9472:
                        b = 9472
                    else:
                        raise ValueError("bad codepoint range in stub payload")
                self.p += 1
                idx = (self.p + self.rot - 1) % 18
                self.slots[idx] = chr((d - b - self.key) % 256)

    def value(self) -> str:
        return "".join(self.slots.get(i, "\x00") for i in range(18))


_VARDEF_RE_TMPL = (
    r"local\s+({name})\s*=\s*\1\s*;?\s*if\s+\1\s*==\s*nil\s+then\s+"
    r"\1\s*=\s*string\.char\((?P<args>[^;]*?)\)\s*end\s*;?"
)
_ACALL_RE_TMPL = r"if\s+not\s+{a}\(\s*({name})\s*,\s*(\d)\s*\)\s*then\s+return\s+{z}\(\)\s*end\s*;?"


def find_panic_stubs(src: str) -> list[PanicStub]:
    results: list[PanicStub] = []
    for head in _STUB_HEAD_RE.finditer(src):
        z, s, p, a, x, f = (head.group(g) for g in ("z", "s", "p", "a", "x", "f"))
        # Grab the rest of the `_a` function body to read ROT / KEY, bounded
        # generously (the body is small, a few hundred chars).
        window = src[head.end():head.end() + 1800]
        rot_m = re.search(r"\(" + re.escape(p) + r"\+(\d+)-1\)%18\+1", window)
        key_m = re.search(r"-(\d+)\)%256\)", window)
        if not rot_m or not key_m:
            continue
        rot = int(rot_m.group(1))
        key = int(key_m.group(1))
        # locate end of the `_a` function definition: first "return true end;"
        rt = window.find("return true end")
        if rt == -1:
            continue
        after_a = head.end() + rt + len("return true end")
        if src[after_a:after_a + 1] == ";":
            after_a += 1

        # 4 variable definitions, consecutively.
        cursor = after_a
        var_defs = []
        ok = True
        for _ in range(4):
            vm = re.match(r"\s*local\s+(\w+)\s*=\s*\1\s*;?\s*if\s+\1\s*==\s*nil\s+then\s+"
                           r"\1\s*=\s*string\.char\((.*?)\)\s*end\s*;?", src[cursor:cursor + 2000], re.S)
            if not vm:
                ok = False
                break
            var_defs.append((vm.group(1), vm.group(2)))
            cursor += vm.end()
        if not ok or len(var_defs) != 4:
            continue

        # 4 `_a(VAR, F)` calls, consecutively.
        a_calls = []
        for _ in range(4):
            cm = re.match(r"\s*if\s+not\s+" + re.escape(a) + r"\(\s*(\w+)\s*,\s*(\d)\s*\)\s*then\s+return\s+"
                           + re.escape(z) + r"\(\)\s*end\s*;?", src[cursor:cursor + 200])
            if not cm:
                ok = False
                break
            a_calls.append((cm.group(1), int(cm.group(2))))
            cursor += cm.end()
        if not ok or len(a_calls) != 4:
            continue

        var_bytes = {}
        try:
            for name, argtext in var_defs:
                var_bytes[name] = _parse_string_char_args(argtext)
        except Exception:
            continue

        sim = _StubDecoderSim(rot, key)
        try:
            for name, f_flag in a_calls:
                sim.feed(var_bytes[name], f_flag)
        except Exception:
            continue

        full_value = sim.value()
        e_value = full_value[0:5]
        m_value = full_value[5:18]

        results.append(PanicStub(
            start=head.start(), end=cursor, rot=rot, key=key,
            s_name=s, z_name=z, e_value=e_value, m_value=m_value,
            full_text=src[head.start():cursor],
        ))
    return results


def annotate_panic_stubs(src: str) -> tuple[str, int]:
    """Replace each panic-string bootstrap with a short, readable comment
    plus a literal reconstruction of the `_s` slot table (so any following
    code, including possible smuggled-in side-effecting statements, keeps
    working byte-for-byte unmodified)."""
    stubs = find_panic_stubs(src)
    if not stubs:
        return src, 0
    out = []
    pos = 0
    count = 0
    for st in stubs:
        out.append(src[pos:st.start])
        full_value = st.e_value + st.m_value
        # _s must hold single-character *strings* (table.concat would turn
        # raw byte numbers into their decimal text instead of the char they
        # represent), so emit an explicit list of 1-char string literals.
        chars_literal = ",".join(_lua_escape(c) for c in full_value)
        comment = (
            f"--[[ [luavex-deobf] decoded panic bootstrap -> "
            f"calls error({_lua_escape(st.m_value)}, 0) when an integrity/env check fails ]] "
        )
        replacement = (
            f"{comment}local {st.z_name}=function() local _v=nil; return _v() end; "
            f"local {st.s_name}={{{chars_literal}}}; "
        )
        out.append(replacement)
        pos = st.end
        count += 1
    out.append(src[pos:])
    return "".join(out), count


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

@dataclass
class StaticReport:
    panic_stubs_found: int = 0
    panic_stub_values: list[tuple[str, str]] = field(default_factory=list)
    qd_decoders_found: int = 0
    qd_decoder_keys: list[int] = field(default_factory=list)
    qd_calls_inlined: int = 0
    fold_passes: int = 0


def run_static_pipeline(src: str) -> tuple[str, StaticReport]:
    report = StaticReport()

    # Normalize line endings for consistent downstream processing.
    src = src.replace("\r\n", "\n").replace("\r", "\n")

    # 1) collect info before mutating
    stubs = find_panic_stubs(src)
    report.panic_stubs_found = len(stubs)
    report.panic_stub_values = [(s.e_value, s.m_value) for s in stubs]

    decoders = find_qd_decoders(src)
    report.qd_decoders_found = len(decoders)
    report.qd_decoder_keys = [d.key for d in decoders]

    # 2) fold obvious literal arithmetic first (cheap, helps nothing else break)
    src = fold_constants(src)

    # 3) inline XOR-table string calls
    src, qd_count = decode_qd_tables(src, find_qd_decoders(src))
    report.qd_calls_inlined = qd_count

    # 4) annotate / simplify panic bootstraps
    src, panic_count = annotate_panic_stubs(src)

    # fold again in case decoding exposed more foldable arithmetic
    src = fold_constants(src)

    return src, report
